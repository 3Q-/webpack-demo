
'use strict';
module.exports = function(){
    var ele = document.createElement('h1');
    ele.innerHTML = 'Fuck Webpack\'s Family At All~~~';
    console.log('modules/Common');
    return ele;
};
