
//require('./style.css');
'use strict';
require('../styles/style.css');

var ele = require('./modules/common');

console.log('This is demo');

document.body.appendChild(ele());
