
//require('./style.css');
'use strict';
require('../styles/style.css');

var ele = require('./modules/common');

console.log('This is list');

document.body.appendChild(ele());
